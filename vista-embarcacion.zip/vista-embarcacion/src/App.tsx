// src/App.tsx
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Embarcacion } from './types';
import EmbarcacionesForm from './componentes/EmbarcacionesFrom';
import EmbarcacionesTable from './componentes/EmbarcacionesTable';

const App: React.FC = () => {

  const [embarcaciones, setEmbarcaciones] = useState<Embarcacion[]>([]);

  const [embarcacionEdit, setEmbarcacionEdit] = useState<Embarcacion | null>(null);

  useEffect(() => {
    obtenerEmbarcaciones();
  }, []);

  const obtenerEmbarcaciones = async () => {
    try {

      const respuesta = await axios.get('/api/embarcaciones');
  
      setEmbarcaciones(respuesta.data);
    } catch (error) {

      console.error(error);
    }
  };


  const manejarCrear = async (embarcacion: Omit<Embarcacion, 'id'>) => {
    try {
  
      await axios.post('/api/embarcaciones', embarcacion);

      obtenerEmbarcaciones();
    } catch (error) {

      console.error(error);
    }
  };


  const manejarActualizar = async (embarcacion: Omit<Embarcacion, 'id'>) => {

    if (!embarcacionEdit) return;
    try {

      await axios.put(`/api/embarcaciones/${embarcacionEdit.id}`, embarcacion);
  
      obtenerEmbarcaciones();
      setEmbarcacionEdit(null);
    } catch (error) {

      console.error(error);
    }
  };

  const manejarEliminar = async (id: number) => {
    try {

      await axios.delete(`/api/embarcaciones/${id}`);
  
      obtenerEmbarcaciones();
    } catch (error) {

      console.error(error);
    }
  };

  const iniciarEdicion = (embarcacion: Embarcacion) => {
  
    setEmbarcacionEdit(embarcacion);
  };

  
  const cancelarEdicion = () => {
    setEmbarcacionEdit(null);
  };

  return (
    <div>
      <h1>Gestión de Embarcaciones</h1>
      <EmbarcacionesForm
        onSubmit={embarcacionEdit ? manejarActualizar : manejarCrear}
        initialData={embarcacionEdit || undefined}
        onCancel={embarcacionEdit ? cancelarEdicion : undefined}
      />
      <EmbarcacionesTable
        embarcaciones={embarcaciones}
        onEdit={iniciarEdicion}
        onDelete={manejarEliminar}
      />
    </div>
  );
};

export default App;