
import React, { useState, useEffect } from "react";
import { Embarcacion } from "../types";

interface EmbarcacionesFormProps {
    onSubmit: (embarcacion: Omit<Embarcacion, 'id'>) => void;
    initialData?: Embarcacion;
    onCancel?: () => void;
}

const EmbarcacionesForm: React.FC<EmbarcacionesFormProps> = ({ onSubmit, initialData, onCancel }) => {
    const [nombre, setNombre] = useState(initialData?.nombre || '');
    const [capacidad, setCapacidad] = useState(initialData?.capacidad || 0);
    const [descripcion, setDescripcion] = useState(initialData?.descripcion || '');
    const [fechaProgramada, setFechaProgramada] = useState(initialData?.fechaProgramada || '');

    useEffect(() => {
        if (initialData) {
            setNombre(initialData.nombre);
            setCapacidad(initialData.capacidad);
            setDescripcion(initialData.descripcion || '');
            setFechaProgramada(initialData.fechaProgramada || '');
        } else {
            setNombre('');
            setCapacidad(0);
            setDescripcion('');
            setFechaProgramada('');
        }
    }, [initialData]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSubmit({ nombre, capacidad, descripcion, fechaProgramada });

        if (!initialData) {
            setNombre('');
            setCapacidad(0);
            setDescripcion('');
            setFechaProgramada('');
        }
    };

    return (
        <form onSubmit={handleSubmit} style={{ marginBottom: '20px' }}>
            <h2>{initialData ? 'Editar Embarcación' : 'Crear Embarcación'}</h2>
            <input
                type="text"
                placeholder="Nombre"
                value={nombre}
                onChange={(e) => setNombre(e.target.value)}
                required
                style={{ marginBottom: '10px', marginRight: '10px' }}
            />
            <input
                type="number"
                placeholder="Capacidad"
                value={capacidad}
                onChange={(e) => setCapacidad(parseFloat(e.target.value))}
                required
                style={{ marginBottom: '10px', marginRight: '10px' }}
            />
            <input
                type="text"
                placeholder="Descripción"
                value={descripcion}
                onChange={(e) => setDescripcion(e.target.value)}
                required
                style={{ marginBottom: '10px', marginRight: '10px' }}
            />
            <input
                type="date"
                placeholder="Fecha Programada"
                value={fechaProgramada}
                onChange={(e) => setFechaProgramada(e.target.value)}
                required
                style={{ marginBottom: '10px', marginRight: '10px' }}
            />
            <button type="submit">
                {initialData ? 'Actualizar' : 'Crear'}
            </button>
            {initialData && onCancel && (
                <button
                    type="button"
                    onClick={onCancel}
                    style={{ marginLeft: '10px' }}
                >
                    Cancelar
                </button>
            )}
        </form>
    );
};

export default EmbarcacionesForm;